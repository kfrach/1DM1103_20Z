#ifndef _dziekanat_h
#define _dziekanat_h

#include "studenci.h"


void najlepszy_student(student dane[100], int ile_rekordow);
void najlepszy_przedmiot(student dane[100], int ile_rekordow);


#endif